package com.example.s.loginfedeisu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn;
    EditText usr;
    EditText psd;
    TextView btnReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usr = (EditText) findViewById(R.id.usr);
        psd = (EditText) findViewById(R.id.psd);
        btn = (Button) findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (usr.getText().toString().isEmpty() || psd.getText().toString().isEmpty())
                {
                    if (usr.getText().toString().isEmpty())
                    {
                        usr.setError("Il campo username non può essere vuoto");
                    }
                    if(psd.getText().toString().isEmpty())
                    {
                        psd.setError("Il campo password non può essere vuoto");
                    }

                }
                if(!usr.getText().toString().isEmpty() && ! psd.getText().toString().isEmpty())
                {
                    String value = usr.toString();

                    Intent myIntent = new Intent(MainActivity.this, LoggedActivity.class);
                    myIntent.putExtra("username", usr.getText().toString());
                    myIntent.putExtra("password", psd.getText().toString());
                    startActivity(myIntent);
                    //Toast.makeText(getApplicationContext(), "LOGIN AVVENUTO", Toast.LENGTH_LONG);
                }



            }
        });

        btnReg = (TextView) findViewById(R.id.btnReg);
        btnReg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Registrazione non implementata", Toast.LENGTH_LONG).show();
            }
        });
    }
}