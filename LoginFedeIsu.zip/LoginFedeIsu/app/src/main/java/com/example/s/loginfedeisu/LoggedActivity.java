package com.example.s.loginfedeisu;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;



public class LoggedActivity extends AppCompatActivity {

    TextView usernameT;
    String grabUser;
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }   protected void onCreate(Bundle savedInstanceState) {
        assert getSupportActionBar() != null;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_logged);

        super.onCreate(savedInstanceState);
        
        Intent intent = getIntent();
        String username=intent.getStringExtra("username");
        String pass=intent.getStringExtra("password");

        //usernameT = (TextView) findViewById(R.id.usr);
        //usernameT.setText(username);
        if((username.equals("Admin") && pass.equals("Password")) ||(username.equals("aaa") && pass.equals("111")))
        {
            usernameT = (TextView) findViewById(R.id.usr);
            grabUser = username;
            usernameT.setTextColor(Color.parseColor("#142591"));
            usernameT.setText("Benvenuto \n" + grabUser);
        }
        else
        {
            usernameT = (TextView) findViewById(R.id.usr);
            usernameT.setText("ACCESSO NON AVVENUTO");
            usernameT.setTextColor(Color.parseColor("#cccccc"));

        }


    }

}
